package edu.highpoint.MyTipCalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button buttonPlusTip;
    Button buttonMinusTip;
    Button buttonCalculateTip;
    EditText editTextNumberDecimalBillAmount;
    EditText editNumberTipPercent;
    EditText editTextNumberDecimalTipAmount;
    EditText editTextNumberDecimalTotalDue;

    Double billAmount;
    Integer myTipPercent;
    Double tipAmount;
    Double finalAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonPlusTip = (Button) findViewById(R.id.buttonPlusTip);
        buttonMinusTip = (Button) findViewById(R.id.buttonMinusTip);
        editNumberTipPercent = (EditText) findViewById(R.id.numberTipPercent);
        buttonCalculateTip = (Button) findViewById(R.id.buttonCalculateTip);
        editTextNumberDecimalBillAmount = (EditText) findViewById(R.id.editTextNumberDecimalBillAmount);
        editTextNumberDecimalTipAmount = (EditText) findViewById(R.id.editTextNumberDecimalTipAmount);
        editTextNumberDecimalTotalDue = (EditText) findViewById(R.id.editTextNumberDecimalTotalDue);


        billAmount = 0.0;
        myTipPercent = 10;
        tipAmount = 0.0;
        finalAmount = 0.0;

        editNumberTipPercent.setText(myTipPercent.toString() + "%");


    }

    public void increaseTip(View view) {
        myTipPercent = myTipPercent + 1;
        editNumberTipPercent.setText(myTipPercent.toString() + "%");
    }

    public void decreaseTip(View view) {
        myTipPercent = myTipPercent - 1;
        editNumberTipPercent.setText(myTipPercent.toString() + "%");
    }

    public void calculateTip(View view){
        String billAmountString = editTextNumberDecimalBillAmount.getText().toString();
        if(billAmountString.matches(""))
            billAmount = 0.0;
        else
            billAmount = Double.parseDouble(billAmountString);

        tipAmount = billAmount * (myTipPercent/100.0);
        editTextNumberDecimalTipAmount.setText("$"+ billAmount.toString());

        finalAmount = billAmount + tipAmount;
        editTextNumberDecimalTotalDue.setText("$"+finalAmount.toString());
    }
}